# poster-girl-l2d-2233
2233娘的 Live2D 看板娘插件(typecho)！

插件发布地址:https://qqdie.com/archives/l2d233.html

## 使用方法

1 上传至站点 `/usr/plugins` 目录下，并将文件夹重命名为l2d233

2 登录后台启用即可

## 使用须知
插件需要jQuery和Font Awesome的支持，如果你的主题没有这两个东西，请去插件设置页面启用一下

## 授权
由于原项目使用 GPL 2.0 协议，故本项目也采用相同的开源协议进行授权。

插件移植自WordPress插件https://github.com/xb2016/poster-girl-l2d-2233
另，2233版权归 bilibili 所有！

## 使用的开源项目
 - [Live2D-Src](https://github.com/journey-ad/live2d_src)